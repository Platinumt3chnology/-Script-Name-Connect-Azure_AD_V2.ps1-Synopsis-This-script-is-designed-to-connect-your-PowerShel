## How to use the files in this directory?

1. Download and Install Postman tool if you don't already have it (https://www.getpostman.com)
2. Import the collection JSON file 
3. Import the environment JSON file - This is a template environment for providing credetials required for connecting to OneRoster server.
4. Edit the environment file and provide required connection values to point to your OneRoster server. 
5. Run the collection against the environment that you have setup in the previous step and ensure that all the tests have passed.
